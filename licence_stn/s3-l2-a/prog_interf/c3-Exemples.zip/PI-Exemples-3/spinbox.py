from tkinter import *

app = Tk()

sb = Spinbox(app, from_=0, to=15)
sb.pack()

app.mainloop()