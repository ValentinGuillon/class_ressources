#Définition de la classe Voiture
class Voiture:
    #Les attributs de la classe
    marque = "Lamborghini"
    modele = "Aventador"
    couleur = "Noir"

#Création de deux instances de la classe Voiture
voiture_1 = Voiture()
voiture_2 = Voiture()

#Afficher la marque des deux voitures crées
print(voiture_1.marque)
print(voiture_2.marque)


