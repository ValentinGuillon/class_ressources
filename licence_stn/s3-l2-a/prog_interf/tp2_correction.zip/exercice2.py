from tkinter import *
from PIL import ImageTk, Image


class Application(Tk): 
    def __init__(self):
        Tk.__init__(self) 
        self.geometry("300x450")
        self['bg'] = 'white'
        self.title('Application bancaire')
        self.creerWidgets()

    def creerLabels(self):
        Label(self, text="Gérez votre compte", \
            font=("Calibri",-15), bg='white').pack(pady=10)
        Label(self, text="en toute simplicité!", \
            font=("Calibri",-15), bg='white').pack(pady=10)
    def creerImage(self):
        img=Image.open("imgBanque.png")
        img=img.resize((150,150))
        img=ImageTk.PhotoImage(img)
        label_img = Label(self, image=img, bg='white')
        label_img.image = img
        label_img.pack(pady=50)
    def creerBoutons(self):
        Button(self,text="Créer un compte",font=('Calibri',-15),\
            width=20, highlightbackground='white').pack()
        Button(self,text="Se connecter",font=('Calibri',-15),\
            width=20,highlightbackground='white').pack()
    def creerWidgets(self):
        self.creerLabels()
        self.creerImage()
        self.creerBoutons()

banque=Application()
banque.mainloop() 